let varName = 'valueHere';
const varName = 'valueHere';
var varName = 'valueHere';





var varName = 'valueHere';
