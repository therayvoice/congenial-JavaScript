function (){
  
  console.log();
}
